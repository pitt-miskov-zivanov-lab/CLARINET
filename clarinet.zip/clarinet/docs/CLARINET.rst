.. CLARINET documentation master file, created by
   sphinx-quickstart on Wed May 19 13:37:15 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

CLARINET functions (:py:mod:`CLARINET.runClarinet`)
===================================================
This page provides a detailed documentation of the CLARINET functions. 

Functions
---------
.. currentmodule:: CLARINET.runClarinet
.. autofunction:: create_eclg

.. currentmodule:: CLARINET.runClarinet
.. autofunction:: node_weighting

.. currentmodule:: CLARINET.runClarinet
.. autofunction:: edge_weighting

.. currentmodule:: CLARINET.runClarinet
.. autofunction:: clustering

.. currentmodule:: CLARINET.runClarinet
.. autofunction:: merge_clusters

.. currentmodule:: CLARINET.runClarinet
.. autofunction:: make_diGraph





